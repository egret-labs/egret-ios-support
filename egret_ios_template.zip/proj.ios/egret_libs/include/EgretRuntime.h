//
//  EgretRuntime.h
//  EgretNativeFramework
//
//  Created by wei huang on 10/30/14.
//  Copyright (c) 2014 egret. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "LifeCycleEvent.h"
#import "ProgressViewDelegate.h"

#define OPTION_EGRET_ROOT "egret.runtime.egretRoot"
#define OPTION_GAME_ID "egret.runtime.gameId"
#define OPTION_LOADER_URL "egret.runtime.loaderUrl"
#define OPTION_UPDATE_URL "egret.runtime.updateUrl"
#define OPTION_PASSWORD "egret.runtime.password"
#define OPTION_LOG_LEVEL "egret.runtime.logLevel"

typedef void (^RequestPromise)(int, NSData *message);
typedef void (^DownloadPromise)(NSString *error);
typedef void (^DownloadProgress)(int received, int length);
typedef void (^ViewAction)();
typedef void (^RuntimeInterfaceBlock)(NSString *);


@interface EgretRuntime : NSObject <LifeCycleEvent>

@property (copy, nonatomic) DownloadProgress progress;
@property (nonatomic) id<ProgressViewDelegate> progressViewDelegate;
@property (nonatomic) CGRect bounds;

+ (EgretRuntime *)createEgretRuntime;
+ (void)destroyEgretRuntime;
+ (EgretRuntime *)getInstance;

- (void)initWithViewController:(UIViewController *)controller;
- (void)initWithRect:(CGRect)bounds inViewController:(UIViewController *)controller;
- (void)setOptions:(NSDictionary *)options;
- (void)run;

- (void)setDownloadProgress:(DownloadProgress)progress addView:(ViewAction)add removeView:(ViewAction)remove;
- (void)requestLoaderUrl:(NSString *)loaderUrl withData:(NSString *)data promise:(RequestPromise)result;
- (void)showProgressView;
- (void)updateProgress:(int)progress length:(int)length;
- (void)hideProgressView;

- (void)showAboveView:(UIView *)view;
- (void)hideAboveView:(UIView *)view;

- (void)enableEgretRuntimeInterface;
- (void)setRuntimeInterface:(NSString *)name block:(RuntimeInterfaceBlock)block;
- (void)callEgretInterface:(NSString *)name value:(NSString *)message;

- (void)registerNestPlugin:(NSString *)name plugin:(id)plugin;

- (void)showTextView;
- (void)hideTextView;
- (void)setMaxLength:(int)length;

@end
