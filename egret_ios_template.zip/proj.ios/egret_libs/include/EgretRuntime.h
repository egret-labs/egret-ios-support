//
//  EgretRuntime.h
//  EgretNativeFramework
//
//  Created by wei huang on 10/30/14.
//  Copyright (c) 2014 egret. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define OPTION_EGRET_ROOT "egret.runtime.egretRoot"
#define OPTION_GAME_ID "egret.runtime.gameId"
#define OPTION_LOADER_URL "egret.runtime.loaderUrl"
#define OPTION_UPDATE_URL "egret.runtime.updateUrl"
#define OPTION_PASSWORD "egret.runtime.password"

typedef void (^RequestPromise)(int, NSData *message);
typedef void (^DownloadPromise)(NSString *error);
typedef void (^DownloadProgress)(int received, int length);
typedef void (^ViewAction)();

@interface EgretRuntime : NSObject

@property (copy, nonatomic) DownloadProgress progress;

+ (EgretRuntime *)getInstance;

- (void)initWithRect:(CGRect)bounds inViewController:(UIViewController *)controller;
- (void)setOptions:(NSDictionary *)options;
- (void)run;
- (void)setDownloadProgress:(DownloadProgress)progress addView:(ViewAction)add removeView:(ViewAction)remove;
- (void)requestLoaderUrl:(NSString *)loaderUrl withData:(NSString *)data promise:(RequestPromise)result;
- (void)showProgressView;
- (void)updateProgress:(int)progress length:(int)length;
- (void)hideProgressView;

- (void)onPause;
- (void)onResume;
- (void)onStop;

@end
