//
//  AppDelegate.m
//
//  Copyright (c) 2014-2015 egret. All rights reserved.
//

#import "AppDelegate.h"
#import "EgretRuntime.h"
#import "ExternalInterface.h"


//TODO: egret publish之后，修改以下常量为生成的game_code名
#define EGRET_PUBLISH_ZIP @"game_code_xxxx.zip"


@interface AppDelegate () {
    NSMutableDictionary *options;
}

@end

@implementation AppDelegate

- (void)initUIWindow {
    // Use RootViewController manage EAGLView
    self.viewController = [[ViewController alloc] initWithNibName:nil bundle:nil];
    self.viewController.landscape = [self isLandscape];

    [[EgretRuntime getInstance] initWithRect:[self.window bounds] inViewController:self.viewController];
    
    // Set RootViewController to window
    [self.window addSubview:self.viewController.view];
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
}

- (BOOL)isLandscape {
    // 横屏 return YES; 竖屏 return NO;
    return NO;
}

- (void)setLoaderUrl:(int)mode {
    switch (mode) {
        case 2:
            // 接入模式2：调试模式，直接使用本地游戏
            options[@OPTION_LOADER_URL] = @"";
            options[@OPTION_UPDATE_URL] = @"";
            break;
        case 1:
            // 接入模式2a: 发布模式，使用指定URL的zip
            options[@OPTION_LOADER_URL] = @"http://www.yourhost.com/game_code.zip";
            options[@OPTION_UPDATE_URL] = @"http://www.yourhost.com/update_url/";

            // 接入模式2b: 发布模式，使用指定的服务器脚本，返回的json参见项目中的egret.json
            // options[@OPTION_LOADER_URL] = @"http://www.yourhost.com/egret.json";
            break;
        default:
            // 接入模式0：发布模式，使用本地zip发布，推荐
            options[@OPTION_LOADER_URL] = EGRET_PUBLISH_ZIP;
            break;
    }
}

- (void)runGame {
    options = [NSMutableDictionary dictionaryWithCapacity:5];

    NSString *egretRoot = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    options[@OPTION_EGRET_ROOT] = egretRoot;
    options[@OPTION_GAME_ID] = @"local";
    options[@OPTION_PASSWORD] = @"";

    [self setLoaderUrl:2];

    [[EgretRuntime getInstance] setOptions:options];
    [[EgretRuntime getInstance] run];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    [self initUIWindow];
    [self runGame];
    
    // Egret（TypeScript）－Runtime（Objective－C）通讯
    [[EgretRuntime getInstance] setRuntimeInterface:@"RuntimeInterface" block:^(NSString *message) {
        NSLog(@"%@", message);
        [[EgretRuntime getInstance] callEgretInterface:@"EgretInterface" value:@"call from runtime"];
    }];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    [[EgretRuntime getInstance] onPause];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    [[EgretRuntime getInstance] onPause];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [[EgretRuntime getInstance] onResume];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [[EgretRuntime getInstance] onResume];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [[EgretRuntime getInstance] onPause];
}

@end
