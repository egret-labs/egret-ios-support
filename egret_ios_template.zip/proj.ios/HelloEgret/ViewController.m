//
//  ViewController.m
//  
//  Copyright (c) 2014-2015 egret. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotate {
	return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
	return self.landscape ? 
			UIInterfaceOrientationMaskLandscape :
			UIInterfaceOrientationMaskPortrait;
}

- (void)showProgressView {
        CGRect container = self.view.frame;
        self.progressView = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
        self.progressView.progress = 0;
        CGRect rect = CGRectMake(0, 0, 300, 5);
        rect.origin.x = container.size.width / 2 - rect.size.width / 2;
        rect.origin.y = container.size.height * 0.8135;
        self.progressView.frame = rect;
        [self.view addSubview:self.progressView];

}

- (void)hideProgressView {
    [self.progressView removeFromSuperview];
}

@end
