//
//  ViewController.m
//  
//  Copyright (c) 2014-2015 egret. All rights reserved.
//

#import "ViewController.h"
#import "EgretRuntime.h"
#import "LoadingView.h"

#define EGRET_PUBLISH_ZIP @"game_code_xxxx.zip"

@interface ViewController ()

@property (nonatomic) BOOL landscape;
@property (nonatomic) NSMutableDictionary *options;

@end

@implementation ViewController

#pragma mark - LifeCycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {

}

- (void)viewDidAppear:(BOOL)animated {
    [self createEgretNative];
}

- (void)enterBackground:(NSNotification *)notification {
    [self pauseEgretNative];
}

- (void)enterForeground:(NSNotification *)notification {
    [self resumeEgretNative];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self destroyEgretNative];
}

- (void)viewDidDisappear:(BOOL)animated {

}

#pragma mark - Rotate

- (BOOL)shouldAutorotate {
	return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
	return [self isLandscape] ?
			UIInterfaceOrientationMaskLandscape :
			UIInterfaceOrientationMaskPortrait;
}

#pragma mark - Egret Native

- (void)createEgretNative {
    _options = [NSMutableDictionary dictionaryWithCapacity:10];
    [EgretRuntime createEgretRuntime];
    [[EgretRuntime getInstance] initWithViewController:self];

    [self runGame];
}

- (void)pauseEgretNative {
    [[EgretRuntime getInstance] onPause];
}

- (void)resumeEgretNative {
    [[EgretRuntime getInstance] onResume];
}

- (void)destroyEgretNative {
    [[EgretRuntime getInstance] onDestroy];
    [EgretRuntime destroyEgretRuntime];
}

- (void)runGame {
    NSString *egretRoot = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    _options[@OPTION_EGRET_ROOT] = egretRoot;
    // 设置游戏的gameId，用于创建一个沙盒环境，该沙盒在应用的documents/egret/$gameId中，
    // 此时的documents/egret/local/
    _options[@OPTION_GAME_ID] = @"local";

    // 设置游戏加载的方式
    [self setLoaderUrl:2];

    // 设置加载进度条，请参考修改LoadingView即可，网络下载资源时打开
    [EgretRuntime getInstance].egretRootView.progressViewDelegate = [[LoadingView alloc] initWithContainerFrame:self.view.frame];
    [[EgretRuntime getInstance] setOptions:_options];
    [self setInterfaces];
    [[EgretRuntime getInstance] run];
}


# pragma mark - Game Opitons

- (BOOL)isLandscape {
    // 横屏返回YES，竖屏返回NO
    return NO;
}

- (void)setLoaderUrl:(int)mode {
    switch (mode) {
        case 2:
            // 接入模式2：调试模式，直接使用本地游戏
            _options[@OPTION_LOADER_URL] = @"";
            _options[@OPTION_UPDATE_URL] = @"";
            break;
        case 1:
            // 接入模式2a: 发布模式，使用指定URL的zip
            _options[@OPTION_LOADER_URL] = @"http://www.yourhost.com/game_code.zip";
            _options[@OPTION_UPDATE_URL] = @"http://www.yourhost.com/update_url/";

            // 接入模式2b: 发布模式，使用指定的服务器脚本，返回的json参见项目中的egret.json
            // options[@OPTION_LOADER_URL] = @"http://www.yourhost.com/egret.json";
            break;
        default:
            // 接入模式0：发布模式，使用本地zip发布，推荐
            _options[@OPTION_LOADER_URL] = EGRET_PUBLISH_ZIP;
            break;
    }
}

- (void)setInterfaces {
    // Egret（TypeScript）－Runtime（Objective－C）通讯
    // setRuntimeInterface: block: 用于设置一个runtime的目标接口
    // callEgretInterface: value: 用于调用Egret的接口，并传递消息
    [[EgretRuntime getInstance] setRuntimeInterface:@"RuntimeInterface" block:^(NSString *message) {
        NSLog(@"%@", message);
        [[EgretRuntime getInstance] callEgretInterface:@"EgretInterface" value:@"call from runtime"];
    }];
}

@end
