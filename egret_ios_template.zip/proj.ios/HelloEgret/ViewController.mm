//
//  ViewController.m
//  
//  Copyright (c) 2014-2015 egret. All rights reserved.
//

#import <sys/xattr.h>
#import "ViewController.h"
#import "EgretRuntime.h"
#import "LoadingView.h"
#import <MediaPlayer/MediaPlayer.h>
#import "SSZipArchive.h"
#import "AsynDownloadTask.h"

#define TEST_URL @"http://10.0.4.147/app1/info.json"
#define EGRET_PUBLISH_ZIP @"game_code_xxxx.zip"

@interface ViewController ()
{
    BOOL _becomeFullScreen;
    BOOL _intialized;
}

@property (nonatomic) BOOL landscape;
@property (nonatomic) NSMutableDictionary *options;
@property (strong, nonatomic) IBOutlet UIProgressView *progressBar;

-(void) videoEnterFullScreen:(NSNotification*) notification;
-(void) videoExitFullScreen:(NSNotification*) notification;

@end

@implementation ViewController

#pragma mark - LifeCycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoEnterFullScreen:) name:MPMoviePlayerWillEnterFullscreenNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoExitFullScreen:) name:MPMoviePlayerWillExitFullscreenNotification object:nil];
}

-(void) videoEnterFullScreen:(NSNotification *)notification
{
    _becomeFullScreen = true;
}

-(void) videoExitFullScreen:(NSNotification *)notification
{
    _becomeFullScreen = false;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewWillAppear:(BOOL)animated {

}

- (void)viewDidAppear:(BOOL)animated {
    NSLog(@"%s", __func__);
    if(!_intialized)
    {
        [self createEgretNative];
        _intialized = true;
    }
}

- (void)enterBackground:(NSNotification *)notification {
    [self pauseEgretNative];
}

- (void)enterForeground:(NSNotification *)notification {
    [self resumeEgretNative];
}

- (void)viewWillDisappear:(BOOL)animated {
    if(_becomeFullScreen)
    {
        return;
    }
    
    [self destroyEgretNative];

    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerWillEnterFullscreenNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerWillExitFullscreenNotification object:nil];
    
}

- (void)viewDidDisappear:(BOOL)animated {

}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

#pragma mark - Rotate

- (BOOL)shouldAutorotate {
	return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
	return [self isLandscape] ?
			UIInterfaceOrientationMaskLandscape :
			UIInterfaceOrientationMaskPortrait;
}

#pragma mark - Egret Native

- (void)createEgretNative {
    _options = [NSMutableDictionary dictionaryWithCapacity:10];
    [EgretRuntime createEgretRuntime];
    [[EgretRuntime getInstance] initWithViewController:self];
    //在后台开始热更新流程
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
        //先进行热更新,然后运行游戏
//        [self hotUpdateAndRunGame];
    });
    //如果希望使用内置的热更新流程，可注释掉下方的startRuntimeAndRunGame函数，使用上方的hotUpdateAndRunGame函数
    [self startRuntimeAndRunGame];
}

- (void)pauseEgretNative {
    [[EgretRuntime getInstance] onPause];
}

- (void)resumeEgretNative {
    [[EgretRuntime getInstance] onResume];
}

- (void)destroyEgretNative {
    [[EgretRuntime getInstance] onDestroy];
    [EgretRuntime destroyEgretRuntime];
}

- (BOOL)addSkipBackupAttributeToItemAtPath:(NSString *) filePathString
{
    //ios version should be iOS 5.1 and later
    NSString *os5 = @"5.0.1";
    NSString *currSysVer = [[UIDevice currentDevice] systemVersion];
    if ([currSysVer compare:os5 options:NSNumericSearch] == NSOrderedSame) // 5.0.1
    {
        assert([[NSFileManager defaultManager] fileExistsAtPath: filePathString]);
        
        const char* filePath = [filePathString fileSystemRepresentation];
        
        const char* attrName = "com.apple.MobileBackup";
        u_int8_t attrValue = 1;
        
        int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
        return result == 0;
    }
    else if ([currSysVer compare:os5 options:NSNumericSearch] == NSOrderedDescending) //5.1 and above
    {
        NSURL* URL= [NSURL fileURLWithPath: filePathString];
        assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);

        NSError *error = nil;
        BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES]
                                      forKey: NSURLIsExcludedFromBackupKey error: &error];
        if(!success){
            NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
        }
        return success;
    }
    else // lower 5.0
    {
        return false;
    }
}

/**
 * 下载更新文件到目标路径，完成时调用完成的回调
 */
-(void)downloadZip:(NSString*) zipUrl
          destPath:(NSString*) destPath
 completionHandler:(void(^)(BOOL isSuccess))completionHandler
{
    @try {
        AsynDownloadTask* connection = [[AsynDownloadTask alloc] initWithDestPath:destPath completionHandler:completionHandler progressHandler:^(float progress) {
            dispatch_async(dispatch_get_main_queue(),^{
                //在主进程更新UI信息,下载进度代表了进度条前50%的流程
                [self.progressBar setProgress:0.5*progress];
            });
        }];
        NSURL *url = [NSURL URLWithString:zipUrl];
        NSURLRequest *theRequest = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
        [connection startRequest:theRequest];
    }
    @catch(NSException *exception) {
        NSLog(@"%@", exception.reason);
    }
}

/**
 * 解压缩到目标路径，替换游戏文件
 */
-(void)unzipAndUpdate:(NSString*) dataPath
          downloadUrl:(NSString*) codeStringUrl{
    NSString *resPath = [[NSBundle mainBundle] resourcePath];
    NSString *gameCodePath = [resPath stringByAppendingString:@"/egret-game"];
    [SSZipArchive unzipFileAtPath:dataPath toDestination:gameCodePath progressHandler:^(NSString * _Nonnull entry, unz_file_info zipInfo, long entryNumber, long total) {
        dispatch_async(dispatch_get_main_queue(),^{
            //在主进程更新UI信息,开始解压缩则意味下载完成，所以进度从50%开始，如果需要更准确的显示下载进度，可使用NSConnection来进行下载
            [self.progressBar setProgress:0.5+0.5*entryNumber/total];
        });
    } completionHandler:^(NSString * _Nonnull path, BOOL succeeded, NSError * _Nonnull error) {
        //成功更新文件，更新本地的版本配置
        if(succeeded){
            NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
            [defaults setObject:codeStringUrl forKey:@"code_url"];
            [self startRuntimeAndRunGame];
        }
    }];
}

/**
 * 更新并运行游戏：如果需要更新，则下载更新包并解压缩到对应路径更新游戏内容，如果不需要更新，则跳过直接开始
 */
- (void)hotUpdateAndRunGame{
    //从给定的url中获得json对象
    NSURL *jsonUrl = [NSURL URLWithString:TEST_URL];
    NSData *data = [NSData dataWithContentsOfURL:jsonUrl];
    NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    //从json对象中获得用以热更新的字段
    NSString *codeStringUrl = json[@"code_url"];
    NSString *updateStringUrl = json[@"update_url"];
    //比对本地配置的更新地址和此次获取的更新地址，如果变更则需要更新
    BOOL needUpdate = NO;
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    NSString *codeUrlSetting = [defaults stringForKey:@"code_url"];
    if(codeStringUrl && ![codeStringUrl isEqualToString:codeUrlSetting]){
        needUpdate = YES;
    }
    NSString *updateUrlSetting = [defaults stringForKey:@"update_url"];
    if(updateStringUrl && ![updateStringUrl isEqualToString:updateUrlSetting]){
        [defaults setObject:updateStringUrl forKey:@"update_url"];
    }
    //需要更新，开始走更新流程
    if(needUpdate){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *path = [paths  objectAtIndex:0];
        //下载文件的存放路径
        NSString *destPath = [path stringByAppendingPathComponent:@"temp.zip"];
        destPath = [destPath stringByStandardizingPath];
        //在主线程执行异步下载流程
        dispatch_async(dispatch_get_main_queue(),^{
            //显示进度条，示例使用进度条显示更新进度，用户可自己定制更新进度的显示方式
            self.progressBar.hidden = NO;
            //
            [self downloadZip:codeStringUrl destPath:destPath completionHandler:^(BOOL isSuccess){
                if(isSuccess){
                    //下载完成，则开始解压缩更新文件，完成更新
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
                        [self unzipAndUpdate:destPath downloadUrl:codeStringUrl];
                    });
                }
                else{
                    //下载失败
                    [self downLoadUpdateFailed];
                }
            }];
        });
    }
    //不需要更新，直接开始运行游戏
    else{
        [self startRuntimeAndRunGame];
    }
}

/**
 * 下载更新包失败的逻辑
 */
- (void)downLoadUpdateFailed{
    NSLog(@"更新失败");
}

- (void)startRuntimeAndRunGame{
    dispatch_async(dispatch_get_main_queue(),^{
        NSString *egretRoot = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        BOOL backupRet = [self addSkipBackupAttributeToItemAtPath: egretRoot];
        if(!backupRet )
        {
            egretRoot = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        }
        _options[@OPTION_EGRET_ROOT] = egretRoot;
        // 设置游戏的gameId，用于创建一个沙盒环境，该沙盒在应用的documents/egret/$gameId中，
        // 此时的documents/egret/local/
        _options[@OPTION_GAME_ID] = @"local";
        _options[@OPTION_LOADER_URL] = @"";
        _options[@OPTION_UPDATE_URL] = [[NSUserDefaults standardUserDefaults] stringForKey:@"update_url"];
        _options[@OPTION_PUBLISH_ZIP] = EGRET_PUBLISH_ZIP;
        
        // 设置游戏加载的方式，在使用hotUpdateAndRunGame函数时不需要调用此api，使用此api会进行内部封装的热更新流程，不适合定制开发。
        [self setLoaderUrl:2];
        
        // 设置加载进度条，请参考修改LoadingView即可，网络下载资源时打开
        [EgretRuntime getInstance].egretRootView.progressViewDelegate = [[LoadingView alloc] initWithContainerFrame:self.view.frame];
        [[EgretRuntime getInstance] setOptions:_options];
        
        [self setInterfaces];
        [[EgretRuntime getInstance] run];
    });
}


# pragma mark - Game Opitons

- (BOOL)isLandscape {
    // 横屏返回YES，竖屏返回NO
    return NO;
}

- (void)setLoaderUrl:(int)mode {
    switch (mode) {
        case 2:
            // 接入模式2：调试模式，直接使用本地游戏
            _options[@OPTION_LOADER_URL] = @"";
            _options[@OPTION_UPDATE_URL] = @"";
            break;
        case 1:
            // 接入模式2a: 发布模式，使用指定URL的zip
            _options[@OPTION_LOADER_URL] = @"http://www.yourhost.com/game_code.zip";
            _options[@OPTION_UPDATE_URL] = @"http://www.yourhost.com/update_url/";

            // 接入模式2b: 发布模式，使用指定的服务器脚本，返回的json参见项目中的egret.json
            // options[@OPTION_LOADER_URL] = @"http://www.yourhost.com/egret.json";
            break;
        default:
            // 接入模式0：发布模式，使用本地zip发布，推荐
            _options[@OPTION_LOADER_URL] = EGRET_PUBLISH_ZIP;
            break;
    }
}

- (void)setInterfaces {
    // Egret（TypeScript）－Runtime（Objective－C）通讯
    // setRuntimeInterface: block: 用于设置一个runtime的目标接口
    // callEgretInterface: value: 用于调用Egret的接口，并传递消息
    [[EgretRuntime getInstance] setRuntimeInterface:@"RuntimeInterface" block:^(NSString *message) {
        NSLog(@"%@", message);
        [[EgretRuntime getInstance] callEgretInterface:@"EgretInterface" value:@"call from runtime"];
    }];
}

@end
