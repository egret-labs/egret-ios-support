#!/bin/bash

# publish_zip.sh

cd proj.ios
git archive -o ../../ios/egret_ios_template.zip master
